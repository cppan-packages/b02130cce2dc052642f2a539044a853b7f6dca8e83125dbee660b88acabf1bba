// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

#pragma once

#if !defined(RXCPP_RX_HPP)
#define RXCPP_RX_HPP

#define RXCPP_LITE
#include "rx-includes.hpp"

#endif
